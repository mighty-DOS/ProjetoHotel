namespace API
{
    public static class Settings
    {
        public static string secret = "Yq3t6w9y$B&E)H@McQfTjWnZr4u7x!A%";
    }
}